const express = require('express');
const session = require('express-session')



const path = require('path')
const app = express();



app.use(express.urlencoded({extended:true}));

app.use(express.static("public"))

app.set('view engine', 'ejs');



const port = 3000;
app.use(session({secret:'Keep it secret',

resave : false,
name:'uniqueSessionID'
,saveUninitialized:false}))


app.use(function(req, res, next) {
    res.set('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
    next();
    });


app.get('/',(req,res)=>
{
if(req.session.loggedIn)

res.redirect('/Home')
else

res.redirect('/login')})


app.get('/Home',(req,res)=>
{
if(req.session.loggedIn) 
{

 res.render('Home')
res.end()
}
else
res.redirect('/login')
})


app.get('/login',(req,res)=>
{

    if(req.session.loggedIn)
    res.redirect('/Home')
    else
    res.render('login',{r:" "})


})




app.post('/authenticate',(req,res,next)=>
{

  




if(req.body.username=='pranav'&&req.body.password=='pass1') 
{
res.locals.username = req.body.username
next()

}

else

res.render('login',{r:"Incorrect Credentials"})



}
,(req,res)=>
{
req.session.loggedIn = true
req.session.username = res.locals.username

console.log(req.session)
 res.redirect('/Home')

})





app.get('/logout',(req,res)=>
{

req.session.loggedIn = false
res.clearCookie('myCookie');
res.clearCookie('connect.sid');
req.session.destroy((err)=>{})

res.redirect("/login")
})
app.listen(port,()=>{console.log('Website is running')});

